import express from "express";
import dotenv from "dotenv";

dotenv.config();

const books=[
    {
        id:1,
        name:"Uqisen Ulasanmi",
        author:'Janob Hechkim',
        year:2023
    },
    {
        id:2,
        name:"HomeWorkni Vaxli Topshir",
        author:'Kimdir Qachondirov',
        year:2021
    },{
        id:3,
        name:"Izsiz yillar",
        author:'Ya Uzim',
        year:2024
    },{
        id:4,
        name:"Vaxt Qadri",
        author:'Yana Uzim',
        year:2015
    },{
        id:5,
        name:"Baxt bu Oila",
        author:'Husan Murodov',
        year:2021
    },
]

const app=express();

const MyLogger=function(req,res,next){
    console.log('This is Log Middleware');
    next();
}

app.use(MyLogger);
app.use(express.json());

app.get('/books', (req,res)=>{
    return res.status(200).json({
        status:'OK',
        message:"Success",
        data:books,
    });
});

app.get('/books.:id',(req,res)=>{
    const bookId=req.params.id;
    const book=books.find((item)=>item.id==bookId);
    if(!book){
        return res.status(404).json({
            message:"Bunday kitob mavjud emas",
        });
    }
    return res.status(200).json({
        status:"OK",
        data:book,
    });
});

app.post('/books',(req,res)=>{
    const {name, author,year}=req.body;
    if(!name || !author || !year){
        return res
        .status(400)
        .json({message:"Yuborilgan ma'lumotlar to'liq emas. "});
    }

    const newBook={id:books.length+1, ...req.body};
    books.push(newBook);
    return res.status(201).json({status:'CREATED',data:newBook});
});

app.put("/books/:id",(req,res)=>{
    const bookId=req.params.id;
    const {name,author,year}=req.body;
    const oldBook=books.find((item)=>item.id==bookId);
    if(!oldBook){
        return res.status(404).json({message:"Bunday kitob mavjud emas"});
    }

    if(!name || !author || !year){
        return res
        .status(400)
        .json({message:"Yuborilgan ma'lumot to'liq emas"});
    }

    books.forEach(item=> {
        if(item.id == bookIdId){
            item.name=name || oldBook.name;
            item.author=author || oldBook.author;
            item.year=year || oldBook.year;
        }
    });
    return res.status(200).json({status:"UPDATED", data:{id:bookId} });
});

app.delete("/books/:id", (req,res)=>{
    const bookId=req.params.id;
    const oldBook=books.find((item)=>item.id==bookId);
    if(!oldBook){
        return res.status(404).json({message:"Bunday kitob mavjud emas"});
    }
    books.splice(bookId-1,1);
    return res.status(200).json({status:"DELETED", data:{id:bookId} });
});

const port =process.env.PORT || 3001;
app.listen(port,(err)=>{
    if(err) throw err;
    console.log(`Server is running on port: ${port}`);
});

